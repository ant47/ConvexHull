/*
	Anthony Yanik
	Comp 282 
	Computing Convex Hull then checking too see if 
	test points are inside or outside of hull
	February 2017
	
	Coordinate.java
*/
public class Coordinate{
	//A coordinate is defined as (X,Y)
	int x;
	int y;
}